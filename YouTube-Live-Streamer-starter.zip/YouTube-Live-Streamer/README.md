# YouTube Live Streamer

Production-oriented starter scaffold for an Android + cloud SaaS that streams user-owned/licensed prerecorded videos to YouTube Live.

## Architecture
- `android/`: Kotlin + Jetpack Compose Android client starter.
- `backend/`: FastAPI API, PostgreSQL-ready SQLAlchemy configuration, auth-ready structure.
- `worker/`: isolated FFmpeg streaming worker image and loop entrypoint.
- `render.yaml`: Render Blueprint starting point.
- `docs/`: deployment, security, and roadmap notes.

> This scaffold is a foundation, not a finished streaming SaaS. OAuth consent verification, production authentication, resumable uploads, billing, and end-to-end stream tests must be completed before public launch.

## Quick start (backend)
1. Copy `backend/.env.example` to `backend/.env`; fill local development values.
2. Create a Python 3.12 virtual environment.
3. `pip install -r backend/requirements.txt`
4. `uvicorn app.main:app --app-dir backend --reload`
5. Open `/health`.

## Android
Open `android/` in Android Studio (recent stable version with JDK 17+). Sync Gradle and run on an emulator/device. Set `API_BASE_URL` in `android/app/build.gradle.kts` before connecting to a deployed API.

## Render deployment
Review `docs/RENDER_DEPLOY.md` first. Create PostgreSQL and private worker services, then configure secrets through Render Environment settings. Do not commit `.env`, OAuth secrets, or stream keys.

## Safety defaults
- Never log OAuth tokens or RTMPS stream keys.
- Never embed backend secrets in the APK.
- Only stream content the user owns or is licensed to broadcast.
- Apply per-user stream concurrency and storage quotas before enabling public signups.
