#!/bin/sh
set -eu
# Skeleton only. Never pass stream keys through logs or shell history.
# Production worker must claim a queue job, retrieve a private media object,
# validate it, build an FFmpeg command safely, publish state/metrics, and clean up.
echo "Streaming worker image ready; queue consumer is not implemented yet."
exec sleep infinity
