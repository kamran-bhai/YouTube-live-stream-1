# Roadmap

## Phase 1 — Foundation
- Repository/CI, API health check, database migrations, configuration validation.
- Android navigation and API connectivity.

## Phase 2 — Identity and media
- Production authentication, account verification, ownership checks.
- Private object storage, resumable upload, metadata and codec validation.

## Phase 3 — Streaming MVP
- Queue-backed stream job state machine: QUEUED → STARTING → LIVE → RETRYING → STOPPED/FAILED.
- FFmpeg loop worker, RTMPS output, idempotent start/stop, watchdog and stream logs.
- Dedicated test YouTube channel and 24-hour soak test.

## Phase 4 — YouTube integration
- OAuth authorization-code flow, state/PKCE where supported, refresh/revoke handling.
- YouTube Data API broadcast management and RTMPS manual-key mode.
- Verify API policies and OAuth verification requirements.

## Phase 5 — SaaS readiness
- Usage quotas, subscriptions, admin console, alerts, backups, load/security testing.
- Staged rollout and support process.
