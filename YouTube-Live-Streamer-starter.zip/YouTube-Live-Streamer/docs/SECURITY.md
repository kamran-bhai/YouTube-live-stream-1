# Security checklist before public beta

- [ ] Implement password hashing (Argon2id) and email verification, or use a vetted identity provider.
- [ ] Use short-lived access tokens, refresh-token rotation, revocation, and rate limits.
- [ ] Encrypt OAuth refresh tokens and RTMPS stream keys with managed key encryption; never log them.
- [ ] Enforce user ownership on every video, channel, stream, and history endpoint.
- [ ] Store media in private object storage and issue short-lived signed URLs.
- [ ] Validate file signature, duration, codec, file size, and content policy; process media in an isolated non-root worker.
- [ ] Add per-user concurrent-stream, storage, and bandwidth quotas.
- [ ] Add idempotency keys and distributed locks to prevent duplicate jobs.
- [ ] Implement queue retries with backoff, dead-letter handling, and explicit job state transitions.
- [ ] Add audit logs, alerting, backup/restore tests, dependency scanning, and incident procedures.
- [ ] Publish privacy policy, terms, copyright policy, and account deletion flow.
