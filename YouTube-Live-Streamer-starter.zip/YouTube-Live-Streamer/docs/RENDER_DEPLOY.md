# Render deployment checklist

1. Push this scaffold to a new GitHub repository named `YouTube-Live-Streamer`.
2. In Render, create a Blueprint from the repository and review every proposed service.
3. Provision a paid PostgreSQL plan appropriate for production and confirm backup/retention settings.
4. Set `JWT_SECRET`, `TOKEN_ENCRYPTION_KEY`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `PUBLIC_BASE_URL`, `API_BASE_URL`, `WORKER_TOKEN`, and object-storage settings in the Render dashboard.
5. Do not expose the worker publicly. Configure it as a private/background worker and restrict network access where possible.
6. Configure Google OAuth consent screen, authorized redirect URI, privacy policy, terms, and required YouTube Data API access.
7. Deploy API first; confirm `/health` returns `{"status":"ok"}`.
8. Deploy worker only after the queue, job-claim protocol, and secret handling are implemented. The current worker is a skeleton and does not poll a production queue yet.
9. Run staging tests with a dedicated YouTube channel before using real users.

## Important Render notes
- The included Blueprint is a starting template. Render service types and worker support depend on the selected plan and current platform options; review it in the dashboard before applying.
- Persistent video storage should use object storage (S3-compatible or equivalent), not the ephemeral filesystem of a web service.
- Long-running streams need an instance/plan that supports persistent worker processes and sufficient outbound bandwidth. Estimate egress costs before launch.
