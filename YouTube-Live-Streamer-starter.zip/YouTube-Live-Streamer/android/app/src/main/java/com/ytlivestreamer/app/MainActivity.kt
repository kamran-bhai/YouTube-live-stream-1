package com.ytlivestreamer.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { HomeScreen() } } }
    }
}

@Composable
private fun HomeScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("YouTube Live Streamer", style = MaterialTheme.typography.headlineMedium)
        Text("Turn your own prerecorded videos into YouTube Live streams.")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Project setup", style = MaterialTheme.typography.titleMedium)
                Text("API: ${BuildConfig.API_BASE_URL}")
                Text("Starter UI only — streaming controls are not wired yet.")
            }
        }
        Button(onClick = { /* TODO: Android Photo Picker and upload flow */ }, modifier = Modifier.fillMaxWidth()) { Text("Select Video") }
        Button(onClick = { /* TODO: OAuth / RTMPS setup */ }, modifier = Modifier.fillMaxWidth()) { Text("Connect YouTube") }
        Button(onClick = { /* TODO: create backend stream job */ }, modifier = Modifier.fillMaxWidth()) { Text("Start Live") }
        Text("Loop, stream status, history and secure settings will be added in later phases.", style = MaterialTheme.typography.bodySmall)
    }
}
